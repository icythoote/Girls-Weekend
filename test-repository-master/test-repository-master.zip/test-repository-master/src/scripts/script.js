// This is where you'll place your javascript code

// open your Developer Tools (CTRL + Shift + j) to see this message :)
console.log("Hello World!");
